"""
JARVIS Cloud-Server
--------------------
Diese Version ist fuer Hosting-Plattformen wie Render.com gedacht.
Der API-Key wird NICHT im Code gespeichert, sondern als "Environment
Variable" (Umgebungsvariable) auf der Hosting-Plattform hinterlegt.
So bleibt er geheim, selbst wenn der Code oeffentlich auf GitHub liegt.

Lokal testen:
    export ANTHROPIC_API_KEY=sk-ant-...    (Mac/Linux)
    set ANTHROPIC_API_KEY=sk-ant-...       (Windows)
    python server.py
"""

import os
import json
import urllib.request
import urllib.error
from flask import Flask, request, Response, send_from_directory

HERE = os.path.dirname(os.path.abspath(__file__))
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"

app = Flask(__name__, static_folder=HERE, static_url_path="")


def get_api_key():
    return os.environ.get("ANTHROPIC_API_KEY")


@app.route("/")
def index():
    return send_from_directory(HERE, "index.html")


@app.route("/<path:path>")
def static_files(path):
    return send_from_directory(HERE, path)


@app.route("/api/chat", methods=["POST", "OPTIONS"])
def chat():
    if request.method == "OPTIONS":
        resp = Response(status=204)
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        return resp

    api_key = get_api_key()
    if not api_key:
        return _json_response(
            {"error": "Kein API-Key konfiguriert. ANTHROPIC_API_KEY als Umgebungsvariable setzen."},
            500,
        )

    try:
        payload = request.get_json(force=True)
    except Exception:
        return _json_response({"error": "Ungueltiges JSON."}, 400)

    payload["model"] = payload.get("model") or "claude-sonnet-4-6"
    payload["max_tokens"] = min(int(payload.get("max_tokens", 1000)), 2000)

    req = urllib.request.Request(
        ANTHROPIC_URL,
        data=json.dumps(payload).encode("utf-8"),
        method="POST",
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": ANTHROPIC_VERSION,
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return _raw_response(resp.read(), resp.status)
    except urllib.error.HTTPError as e:
        return _raw_response(e.read(), e.code)
    except Exception as e:
        return _json_response({"error": f"Verbindung zur Anthropic-API fehlgeschlagen: {e}"}, 502)


def _json_response(obj, status):
    return _raw_response(json.dumps(obj).encode("utf-8"), status)


def _raw_response(raw_bytes, status):
    resp = Response(raw_bytes, status=status, mimetype="application/json")
    resp.headers["Access-Control-Allow-Origin"] = "*"
    return resp


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8723))
    app.run(host="0.0.0.0", port=port)
